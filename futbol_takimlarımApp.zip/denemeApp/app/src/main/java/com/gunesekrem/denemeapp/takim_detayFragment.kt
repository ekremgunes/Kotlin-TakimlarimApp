package com.gunesekrem.denemeapp

import android.content.Context
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import kotlinx.android.synthetic.main.fragment_takim_detay.*


class takim_detayFragment : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        /*arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }*/
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_takim_detay, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setMenuVisibility(false)

        arguments?.let{
            val gelen_id = takim_detayFragmentArgs.fromBundle(it).takimId

        context?.let {

            try {
                val database = it.openOrCreateDatabase("TakimlarDb", Context.MODE_PRIVATE,null)
                val cursor = database.rawQuery("SELECT * FROM Takimlar WHERE id = ? ", arrayOf(gelen_id.toString()))

                val takim_Adi_index = cursor.getColumnIndex("takim_adi")
                val takim_img_index = cursor.getColumnIndex("takim_img")

                while (cursor.moveToNext()){
                    takim_adi_detay.setText(cursor.getString(takim_Adi_index))

                    val bytedizisi = cursor.getBlob(takim_img_index)
                    val bitmap = BitmapFactory.decodeByteArray(bytedizisi,0,bytedizisi.size)
                    takim_detay_imageView.setImageBitmap(bitmap)
                }
                cursor.close()


            }catch (e :Exception){
                val action = takim_detayFragmentDirections.actionTakimDetayFragmentToTakimListFragment()
                Navigation.findNavController(view).navigate(action)
                e.printStackTrace()

            }
        }
        }
    }


}