package com.gunesekrem.denemeapp

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.text.Layout
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListAdapter
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.fragment_list.*



class takim_listFragment : Fragment() {
    var takimListesi = ArrayList<String>()
    var takimIdListesi = ArrayList<Int>()
    private lateinit var listeAdapter : TakimListRecylerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        listeAdapter = TakimListRecylerAdapter(takimListesi,takimIdListesi)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = listeAdapter

        verileriAl()


    }

    fun verileriAl(){
        try {

            context?.let {
                val database = it.openOrCreateDatabase("TakimlarDb", Context.MODE_PRIVATE,null)

                val cursor = database.rawQuery("SELECT * FROM Takimlar",null)

                val takim_Adi_index = cursor.getColumnIndex("takim_adi")
                val takim_Id_index = cursor.getColumnIndex("id")

                takimListesi.clear()
                takimIdListesi.clear()

                while (cursor.moveToNext()){

                    //println((cursor.getInt(takim_Id_index)).toString())

                    takimListesi.add(cursor.getString(takim_Adi_index))
                    takimIdListesi.add(cursor.getInt(takim_Id_index))

                }

                listeAdapter.notifyDataSetChanged() //yeni veri geldiginde listenin güncellenmesi içinmiş
                cursor.close()

            }


        }catch (e :Exception){
            println("veri alınamadı")
            e.printStackTrace()
        }


    }



}