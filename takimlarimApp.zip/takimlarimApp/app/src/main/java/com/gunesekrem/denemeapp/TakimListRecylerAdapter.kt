package com.gunesekrem.denemeapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.takim_list_rows.view.*

class TakimListRecylerAdapter (val takim_name_List : ArrayList<String>,val takim_id_List : ArrayList<Int>)
    : RecyclerView.Adapter<TakimListRecylerAdapter.takimHolder>() {

    class takimHolder(itemView : View) : RecyclerView.ViewHolder(itemView){

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): takimHolder {

        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.takim_list_rows,parent,false)
        return takimHolder(view)

    }

    override fun onBindViewHolder(holder: takimHolder, position: Int) {

        holder.itemView.takim_row.text = takim_name_List[position]
        holder.itemView.takim_row.setOnClickListener {

            val action = takim_listFragmentDirections.actionTakimListFragmentToTakimDetayFragment(takim_id_List[position])
            Navigation.findNavController(it).navigate(action)

        }
    }

    override fun getItemCount(): Int {
        return takim_name_List.size
    }
}
